export { default as paymentReduceer } from "./Payment/Plan/modal/slice";
