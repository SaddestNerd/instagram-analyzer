export const events = {
  connect: "connect",
  disconnect: "disconnect",
  gamingSessionState: "gamingSessionState",
}
